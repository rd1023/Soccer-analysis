import React, { useState } from 'react';

interface Cue {
  type: string;
  timestamp: string;
  team: string;
  player: string;
  note?: string;
}

const LiveMatchWidget: React.FC = () => {
  const [cues, setCues] = useState<Cue[]>([]);
  const [currentCue, setCurrentCue] = useState<Cue>({
    type: '',
    timestamp: '',
    team: '',
    player: '',
    note: '',
  });

  const addCue = () => {
    setCues([...cues, currentCue]);
    setCurrentCue({ type: '', timestamp: '', team: '', player: '', note: '' });
  };

  return (
    <div style={{ padding: '1rem', border: '1px solid #ccc' }}>
      <h3>Live Match Mode</h3>
      <input placeholder="Cue Type" onChange={e => setCurrentCue({ ...currentCue, type: e.target.value })} />
      <input placeholder="Timestamp (MM:SS)" onChange={e => setCurrentCue({ ...currentCue, timestamp: e.target.value })} />
      <input placeholder="Team" onChange={e => setCurrentCue({ ...currentCue, team: e.target.value })} />
      <input placeholder="Player" onChange={e => setCurrentCue({ ...currentCue, player: e.target.value })} />
      <textarea placeholder="Note" onChange={e => setCurrentCue({ ...currentCue, note: e.target.value })}></textarea>
      <button onClick={addCue}>Add Cue</button>

      <ul>
        {cues.map((cue, idx) => (
          <li key={idx}>{cue.timestamp} - {cue.type} ({cue.team}, {cue.player})</li>
        ))}
      </ul>
    </div>
  );
};

export default LiveMatchWidget;
