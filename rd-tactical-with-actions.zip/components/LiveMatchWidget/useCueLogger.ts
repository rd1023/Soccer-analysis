export const logCue = (cue: any) => {
  console.log("Cue logged:", cue);
};