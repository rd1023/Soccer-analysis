from reportlab.pdfgen import canvas

def build_pdf():
    c = canvas.Canvas("match-report.pdf")
    c.drawString(100, 750, "RD Tactical Match Report")
    c.save()
    print("✅ PDF Created: match-report.pdf")

build_pdf()