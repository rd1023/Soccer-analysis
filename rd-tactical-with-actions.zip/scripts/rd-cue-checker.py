import json

with open('examples/match-events.json') as f:
    data = json.load(f)

required_fields = ["type", "timestamp", "team", "player"]

for i, cue in enumerate(data.get("cues", [])):
    missing = [field for field in required_fields if field not in cue]
    if missing:
        print(f"❌ Cue {i+1} missing: {', '.join(missing)}")
    else:
        print(f"✅ Cue {i+1}: {cue['timestamp']} - {cue['type']}")
