# RD Tactical

RD Tactical is an AI-assisted soccer game analysis system that includes:

- 🎥 **LiveMatchWidget** — React component for tagging game cues
- 🧠 **useCueLogger.ts** — Utility for logging tactical actions
- 📊 **rd-cue-checker.py** — Python script to validate match events
- 🧾 **rd-pdf-builder.py** — Auto-generates a basic match report PDF
- 🧪 **match-events.json** — Example cue data for testing

## Usage

1. Run `rd-cue-checker.py` to validate tagged cues
2. Run `rd-pdf-builder.py` to generate a simple match PDF
3. Integrate `LiveMatchWidget.tsx` into your React interface

---

## Setup

No build required. To test the scripts:

```bash
cd scripts/
python3 rd-cue-checker.py
python3 rd-pdf-builder.py
```

## License

MIT — use it, fork it, build it better.
